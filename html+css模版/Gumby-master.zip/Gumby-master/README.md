Gumby version 2 has arrived!
============================

Gumby Framework version 2 has been released and we have moved all development to our new [GitHub organisation](https://github.com/GumbyFramework/).
Although we will attempt to answer any issues, this repo will no longer be maintained. We recommend you upgrade to version two and check out some of our awesome new features!

Clone Gumby Framework version 2 - https://github.com/GumbyFramework/gumby

Check out the cool updates and read the documentation - http://gumbyframework.com/
